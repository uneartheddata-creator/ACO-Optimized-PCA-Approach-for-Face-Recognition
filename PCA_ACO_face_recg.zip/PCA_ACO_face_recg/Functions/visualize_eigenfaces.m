function visualize_eigenfaces(Eigenfaces, imgHeight, imgWidth, numEigenfaces)
    % Create a figure for displaying eigenfaces
    figure;

    % Loop through the number of eigenfaces to visualize
    for i = 1:numEigenfaces
        % Reshape the eigenface to match the original image dimensions
        eigenface = reshape(Eigenfaces(:, i), [imgHeight, imgWidth]);

        % Normalize the eigenface for better visualization
        eigenface = mat2gray(eigenface);

        % Display the eigenface in a subplot
        subplot(2, ceil(numEigenfaces / 2), i);
        imshow(eigenface);
        title(sprintf('Eigenface %d', i));
    end

    % Set overall title for the figure
    sgtitle('Eigenfaces Visualization');
end

% Example usage of the visualize_eigenfaces function
% Assuming you have already run PCA_ACO and have the eigenfaces


