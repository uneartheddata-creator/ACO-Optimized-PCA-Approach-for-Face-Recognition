function fitness = evaluateFitness(Eigenfaces, selectedIndices)
    % Evaluate fitness based on reconstruction error
    % selectedIndices: Indices of the selected eigenfaces

    % Use the selected eigenfaces to reconstruct the original data
    selectedEigenfaces = Eigenfaces(:, selectedIndices);
    reconstructedData = selectedEigenfaces * selectedEigenfaces';

    % Compute reconstruction error
    originalData = Eigenfaces * Eigenfaces'; % This should be the original centered data
    error = originalData - reconstructedData;
    fitness = norm(error, 'fro'); % Frobenius norm of the reconstruction error
end
