
clc
clear all
close all
addpath('Functions');
% Parameters
Database = 'ORL'; % Database Path
ff = '.pgm'; % File format of Images
numSamples = 5; % Number of sample images to display

% Create a figure for displaying images
figure;
colormap(gray);

% Loop through the first few subjects and display one image per subject
for i = 1:numSamples
    % Construct the image filename
    imgPath = fullfile(Database, sprintf('s%d', i), sprintf('%d%s', 1, ff));
    
    % Check if the image file exists
    if exist(imgPath, 'file')
        % Read the image
        img = imread(imgPath);
        
        % Display the image in a subplot
        subplot(1, numSamples, i);
        imshow(img);
        title(sprintf('Subject %d', i));
    else
        disp(['File "', imgPath, '" does not exist.']);
    end
end

% Set overall title for the figure
sgtitle('Sample Images from ORL Database');

Results=[];
Precision=[];
Accuracy=[];
F1_score=[];
Recall=[];
ss=10; % sample set size
ns=40; % number of subjects
% ind=randperm(ss);% randomizing the selection of training and testing images
ind=[4 10 2 1 8 3 7 9 6 5];
dimensions=13; % Number of desired dimensions
DatabasePath='ORL\s'; % DatabasePath
ff='.pgm'; % file format of Images
for TrNum=1:(ss-1)
% ind=randperm(ss);% randomizing the selection of training and testing images    
TsNum=ss-TrNum; % Remained Number of Images for testing
if (dimensions<1 | dimensions>TrNum*ns)
    fprintf('Dimensions selection is incorrect it should be in the range of %d and %d\n',1,TrNum*ns);
    return
end
%% Creating Database of Training and Testing Images
    escImages=ind(TrNum+1:ss); % Escape Images for testing    
    [Tr,DS]=process_images(ns,DatabasePath,ff,escImages);
    escImages=ind(1:TrNum); % Escape Images that are already used in training
    [Ts,TDS]=process_images(ns,DatabasePath,ff,escImages);

    %% Performing PCA_Test
    [recp,rectime,outd,recd]= PCA_face_recongition(Tr,Ts,TrNum,TsNum,dimensions,TrNum);
    [A, P, R, F1] = Evaluation_model(ns, TsNum, outd, recd); % Precision and Recall Results
    
    Results=[Results;recp,rectime,TDS,DS];
    Precision=[Precision; P];
    Recall=[Recall; R];
    F1_score=[F1_score; F1];
    Accuracy=[Accuracy; A];

end
%% Graphing Results
figure('Name','Recognition Percentage vs Number of Training sample per class','NumberTitle','off')
bar(1:TrNum,Results(:,1,1,1)*100);
title('Recognition Percentage vs Number of Training sample per class');
xlabel('Number of Training sample per class');
ylabel('Recognition Percentage');

figure('Name','Precision and Recall Results','NumberTitle','off')
subplot(2,1,1)
pcolor(Precision'*100)
colorbar();
xlabel('Number of Training sample per class');
ylabel('Class ID');
title('Precision Results')

subplot(2,1,2)
pcolor(Recall'*100)
colorbar();
xlabel('Number of Training sample per class');
ylabel('Class ID');
title('Recall Results')

figure('Name','F1 score and Accuracy Resuls','NumberTitle','off')
subplot(2,1,1)
pcolor(F1_score'*100)
colorbar();
xlabel('Number of Training sample per class');
ylabel('Class ID');
title('F1_score Results')

subplot(2,1,2)
pcolor(Accuracy'*100)
colorbar();
xlabel('Number of Training sample per class');
ylabel('Class ID');
title('Accuracy Results')

M=mean(Tr,2);
[Eigenfaces] = PCA_ACO(Tr, M, dimensions)
imgHeight = 112; % Example height, adjust as necessary
imgWidth = 92; % Example width, adjust as necessary

% Number of eigenfaces to visualize
numEigenfaces = 10;

% Assuming Eigenfaces is the matrix returned by PCA_ACO function
% Call the function to visualize the eigenfaces
visualize_eigenfaces(Eigenfaces, imgHeight, imgWidth, numEigenfaces);
