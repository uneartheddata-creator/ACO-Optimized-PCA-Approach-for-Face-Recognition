function [optimizedIndices] = ACO(Eigenfaces, dimensions)
    % ACO Optimize the selection of eigenfaces using Ant Colony Optimization
    
    % Parameters
    numAnts = 5;
    numIterations = 10;
    alpha = 1;
    beta = 2;
    rho = 0.1; % Pheromone evaporation rate
    numComponents = size(Eigenfaces, 2);
    
    % Initialize pheromone levels
    pheromone = ones(numComponents, 1);
    
    % Fitness function: Reconstruction error
    fitnessFunction = @(selectedIndices) evaluateFitness(Eigenfaces, selectedIndices);
    
    bestIndices = [];
    bestFitness = Inf;
    
    for iter = 1:numIterations
        solutions = cell(numAnts, 1);
        fitness = zeros(numAnts, 1);
        
        % Construct solutions
        for ant = 1:numAnts
            solution = [];
            for component = 1:numComponents
                if rand < (pheromone(component)^alpha)
                    solution = [solution, component];
                end
            end
            if length(solution) > dimensions
                solution = solution(1:dimensions);
            end
            solutions{ant} = solution;
            fitness(ant) = fitnessFunction(solution);
        end
        
        % Update pheromones
        for component = 1:numComponents
            deltaPheromone = sum(1 ./ fitness) / numAnts;
            pheromone(component) = (1 - rho) * pheromone(component) + deltaPheromone;
        end
        
        % Track the best solution
        [minFitness, idx] = min(fitness);
        if minFitness < bestFitness
            bestFitness = minFitness;
            bestIndices = solutions{idx};
        end
         % Record fitness history
        fitnessHistory(iter) = minFitness;
        % Record pheromone levels
        pheromoneLevels = pheromone;
    end
    
    optimizedIndices = bestIndices;
       

% Plot fitness history
figure;

plot(1:numIterations, fitnessHistory, 'b.-');
xlabel('Iteration');
ylabel('Fitness (Reconstruction Error)');
title('Fitness History of ACO Optimization');


end
