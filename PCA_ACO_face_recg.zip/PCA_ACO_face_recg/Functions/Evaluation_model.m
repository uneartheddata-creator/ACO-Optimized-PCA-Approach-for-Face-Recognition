function [Accuracy, Precision, Recall, F1_Score] = Evaluation_model(ns, TsNum, outd, recd)
    % Initialize variables
    TI = zeros(1, ns);
    for i = 1:ns
        TI(i) = length(find(recd == i));
        if (TI(i) == 0)
            TI(i) = Inf;
        end
    end

    k = 0;
    CI = zeros(1, ns);
    for i = 1:ns
        for j = 1:TsNum
            k = k + 1;
            if (recd(k) == outd(k))
                CI(i) = CI(i) + 1;
            end
        end
    end

    TA = TsNum * ones(1, ns);

    % Calculate metrics
    Accuracy = CI ./ TA; % Accuracy
    Precision = CI ./ TI;   % Precision
    Recall = CI ./ TA;      % Recall

    % Calculate F1 Score
    F1_Score = 2 * (Precision .* Recall) ./ (Precision + Recall);

    % Handle cases where precision or recall is NaN (division by zero)
    Precision(isnan(Precision)) = 0;
    Recall(isnan(Recall)) = 0;
    F1_Score(isnan(F1_Score)) = 0;
end
