function [Eigenfaces] = PCA_ACO(Tr, M, dimensions)
    % PCA_CORE Perform Principal Component Analysis with ACO optimization

    %% Find the mean centered data 'A'
    A = Tr - repmat(M, 1, size(Tr, 2));

    %% Find Covariance Matrix's Eigenvector using Surogate Method to reduce Computational Cost
    L = cov(A); % Surogate Matrix of mean subtracted
    [U, D] = eig(L); % Eigen Vectors of Surogate Matrix

    %% Sorting Eigenvectors to select the most dominant eigenvectors
    eigValue = diag(D);
    [~, IX] = sort(eigValue, 'descend');
    L_eig_vec = U(:, IX);

    %% Normalization (optional)
    norm_eigVector = sqrt(sum(L_eig_vec.^2));
    L_eig_vec = L_eig_vec ./ repmat(norm_eigVector, size(L_eig_vec, 1), 1);

    %% Obtain initial eigenfaces
    Eigenfaces = A * L_eig_vec;

    %% Apply ACO to optimize eigenface selection
    optimizedIndices = ACO(Eigenfaces, dimensions);

    %% Dimensionality reduction using optimized indices
    Eigenfaces = Eigenfaces(:, optimizedIndices);
    
end
